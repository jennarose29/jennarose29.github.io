///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;
	//lamp
	bReturn = CreateGLTexture("../../Utilities/textures/lampbase.jpg",
		"lampbase");
	bReturn = CreateGLTexture("../../Utilities/textures/lampshade.jpg",
		"lampshade");
	bReturn = CreateGLTexture("../../Utilities/textures/lamppole.jpg",
		"lamppole");

	//couch
	bReturn = CreateGLTexture("../../Utilities/textures/couchback.jpg",
		"couchblue");
	//rug
	bReturn = CreateGLTexture("../../Utilities/textures/bwrug.jpg",
		"rug");

	//coffeetable
	bReturn = CreateGLTexture(
		"../../Utilities/textures/rusticwood.jpg",
		"table");

	//decor
	bReturn = CreateGLTexture(
		"../../Utilities/textures/globe.jpg",
		"globe");

	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Material for the floor
	OBJECT_MATERIAL floorMaterial;
	floorMaterial.tag = "floor";
	floorMaterial.ambientColor = glm::vec3(0.4f, 0.26f, 0.13f);
	floorMaterial.ambientStrength = 0.3f;
	floorMaterial.diffuseColor = glm::vec3(0.4f, 0.26f, 0.13f);
	floorMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	floorMaterial.shininess = 4.0f;
	m_objectMaterials.push_back(floorMaterial);

	// Material for the lamp base
	OBJECT_MATERIAL lampBaseMaterial;
	lampBaseMaterial.tag = "lampbase";
	lampBaseMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	lampBaseMaterial.ambientStrength = 0.2f;
	lampBaseMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	lampBaseMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.7f);
	lampBaseMaterial.shininess = 32.0f;
	m_objectMaterials.push_back(lampBaseMaterial);

	// Material for the lamp pole
	OBJECT_MATERIAL lampPoleMaterial;
	lampPoleMaterial.tag = "lamppole";
	lampPoleMaterial.ambientColor = glm::vec3(0.7f, 0.7f, 0.7f);
	lampPoleMaterial.ambientStrength = 0.2f;
	lampPoleMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	lampPoleMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	lampPoleMaterial.shininess = 64.0f;
	m_objectMaterials.push_back(lampPoleMaterial);

	// Material for the lamp shade
	OBJECT_MATERIAL lampShadeMaterial;
	lampShadeMaterial.tag = "lampshade";
	lampShadeMaterial.ambientColor = glm::vec3(0.9f, 0.9f, 0.8f);
	lampShadeMaterial.ambientStrength = 0.5f;
	lampShadeMaterial.diffuseColor = glm::vec3(0.9f, 0.9f, 0.8f);
	lampShadeMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	lampShadeMaterial.shininess = 8.0f;
	m_objectMaterials.push_back(lampShadeMaterial);

	// Material for the couch
	OBJECT_MATERIAL couchMaterial;
	couchMaterial.tag = "couch";
	couchMaterial.ambientColor = glm::vec3(0.0f, 0.2f, 0.5f);
	couchMaterial.ambientStrength = 0.3f;
	couchMaterial.diffuseColor = glm::vec3(0.0f, 0.3f, 0.7f);
	couchMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.2f);
	couchMaterial.shininess = 4.0f;
	m_objectMaterials.push_back(couchMaterial);

	// Material for the rug
	OBJECT_MATERIAL rugMaterial;
	rugMaterial.tag = "rug";
	rugMaterial.ambientColor = glm::vec3(0.8f, 0.8f, 0.8f);
	rugMaterial.ambientStrength = 0.4f;
	rugMaterial.diffuseColor = glm::vec3(0.9f, 0.9f, 0.9f);
	rugMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	rugMaterial.shininess = 1.0f;
	m_objectMaterials.push_back(rugMaterial);

	// Material for the table
	OBJECT_MATERIAL tableMaterial;
	tableMaterial.tag = "table";
	tableMaterial.ambientColor = glm::vec3(0.5f, 0.35f, 0.05f);
	tableMaterial.ambientStrength = 0.2f;
	tableMaterial.diffuseColor = glm::vec3(0.6f, 0.4f, 0.1f);
	tableMaterial.specularColor = glm::vec3(0.3f, 0.2f, 0.1f);
	tableMaterial.shininess = 16.0f;
	m_objectMaterials.push_back(tableMaterial);

	// Material for the globe
	OBJECT_MATERIAL globeMaterial;
	globeMaterial.tag = "globe";
	globeMaterial.ambientColor = glm::vec3(0.1f, 0.3f, 0.6f);
	globeMaterial.ambientStrength = 0.2f;
	globeMaterial.diffuseColor = glm::vec3(0.2f, 0.5f, 0.8f);
	globeMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	globeMaterial.shininess = 64.0f;
	m_objectMaterials.push_back(globeMaterial);
}


/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting - to use the default rendered 
	// lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	// Light 1: Point light from the lamp (warm white)
	m_pShaderManager->setBoolValue("lights[0].isEnabled", true);
	m_pShaderManager->setIntValue("lights[0].type", 0); // 0 = point light
	m_pShaderManager->setVec3Value("lights[0].position", glm::vec3(-7.0f, 2.5f, 0.0f)); // Position above the lamp
	m_pShaderManager->setVec3Value("lights[0].direction", glm::vec3(0.0f, -1.0f, 0.0f)); // Pointing downward
	m_pShaderManager->setVec3Value("lights[0].color", glm::vec3(1.0f, 0.95f, 0.8f)); // Warm white color
	m_pShaderManager->setFloatValue("lights[0].intensity", 1.0f);
	m_pShaderManager->setFloatValue("lights[0].constant", 1.0f);
	m_pShaderManager->setFloatValue("lights[0].linear", 0.09f);
	m_pShaderManager->setFloatValue("lights[0].quadratic", 0.032f);
	m_pShaderManager->setFloatValue("lights[0].cutOff", glm::cos(glm::radians(15.0f)));
	m_pShaderManager->setFloatValue("lights[0].outerCutOff", glm::cos(glm::radians(20.0f)));

	// Light 2: Directional light (blue-tinted, like moonlight through a window)
	m_pShaderManager->setBoolValue("lights[1].isEnabled", true);
	m_pShaderManager->setIntValue("lights[1].type", 1); // 1 = directional light
	m_pShaderManager->setVec3Value("lights[1].position", glm::vec3(0.0f, 0.0f, 0.0f)); // Not used for directional lights
	m_pShaderManager->setVec3Value("lights[1].direction", glm::vec3(0.5f, -0.8f, -0.2f)); // Coming from upper right
	m_pShaderManager->setVec3Value("lights[1].color", glm::vec3(0.5f, 0.5f, 0.8f)); // Blue-tinted light
	m_pShaderManager->setFloatValue("lights[1].intensity", 0.6f);
	m_pShaderManager->setFloatValue("lights[1].constant", 1.0f);
	m_pShaderManager->setFloatValue("lights[1].linear", 0.0f);
	m_pShaderManager->setFloatValue("lights[1].quadratic", 0.0f);
	m_pShaderManager->setFloatValue("lights[1].cutOff", glm::cos(glm::radians(0.0f)));
	m_pShaderManager->setFloatValue("lights[1].outerCutOff", glm::cos(glm::radians(0.0f)));

	// Light 3: Spotlight from above (optional third light)
	m_pShaderManager->setBoolValue("lights[2].isEnabled", true);
	m_pShaderManager->setIntValue("lights[2].type", 2); // 2 = spotlight
	m_pShaderManager->setVec3Value("lights[2].position", glm::vec3(5.0f, 5.0f, -2.0f)); // Above the coffee table
	m_pShaderManager->setVec3Value("lights[2].direction", glm::vec3(0.0f, -1.0f, 0.0f)); // Pointing downward
	m_pShaderManager->setVec3Value("lights[2].color", glm::vec3(1.0f, 1.0f, 0.9f)); // Slightly warm white
	m_pShaderManager->setFloatValue("lights[2].intensity", 0.8f);
	m_pShaderManager->setFloatValue("lights[2].constant", 1.0f);
	m_pShaderManager->setFloatValue("lights[2].linear", 0.09f);
	m_pShaderManager->setFloatValue("lights[2].quadratic", 0.032f);
	m_pShaderManager->setFloatValue("lights[2].cutOff", glm::cos(glm::radians(12.0f)));
	m_pShaderManager->setFloatValue("lights[2].outerCutOff", glm::cos(glm::radians(17.0f)));

	// Disable any unused lights
	m_pShaderManager->setBoolValue("lights[3].isEnabled", false);
}


	


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh(); //floor and rug
	m_basicMeshes->LoadCylinderMesh(); //lamp and table
	m_basicMeshes->LoadTaperedCylinderMesh(); //lamp
	m_basicMeshes->LoadSphereMesh(); //table decor
	m_basicMeshes->LoadBoxMesh(); //couch

	//load textures
	LoadSceneTextures();

	//define materials for pbjects in living room
	DefineObjectMaterials();

	//add light source
	SetupSceneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	//******FLOOR******
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	//color
	SetShaderColor(0.4, 0.26, 0.13, 1); //brown floor
	//material
	SetShaderMaterial("floor");
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	//******LAMP******
	//draw base of the lamp
	scaleXYZ = glm::vec3(0.4f, 0.07f, 0.4f); // scale to be wide and flat
	positionXYZ = glm::vec3(-7.0f, 0.0f, 0.0f); //position on plane to left of origin

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.4, 0.4, 0.4, 1.0); //dark gray color
	//set texture and material
	SetShaderTexture("lampbase");
	SetShaderMaterial("lampbase");
	
	//draw
	m_basicMeshes->DrawCylinderMesh();

	//draw the lamp pole
	scaleXYZ = glm::vec3(0.05f, 2.0f, 0.05f); // scale to be tall and skinny
	positionXYZ = glm::vec3(-7.0f, 0.0f, 0.0f); //position on plane to left of origin on the base

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.7, 0.7, 0.7, 1.0); //light gray color
	//set texture and material
	SetShaderTexture("lamppole");
	SetShaderMaterial("lamppole");

	//draw
	m_basicMeshes->DrawCylinderMesh();

	//draw the lamp shade
	scaleXYZ = glm::vec3(0.4f, 0.8f, 0.4f); // scale to be wider than pole and accurate size
	positionXYZ = glm::vec3(-7.0f, 2.0f, 0.0f); //position on plane to left of origin on pole

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.9, 0.9, 0.8, 1.0); //offwhite color
	//set texture and material
	SetShaderTexture("lampshade");
	SetShaderMaterial("lampshade");

	//draw
	m_basicMeshes->DrawTaperedCylinderMesh();

	////******RUG******
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.5f, 0.5f, 1.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.0f, 0.1f, 2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1, 0, 3, 1); //pink rug
	SetShaderTexture("rug");
	SetShaderMaterial("rug");
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();


	//******COUCH******
	//base
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.0f, 1.0f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.5, -1.0);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0, 2, 5, 1); //blue couch
	SetShaderTexture("couchblue");
	SetShaderMaterial("couch");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	//backrest
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.0f, 1.75f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 1.0f, -2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0, 2, 5, 1); //blue couch
	SetShaderTexture("couchblue");
	SetShaderMaterial("couch");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	//left arm
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 1.0f, 1.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-2.75f, 1.0f, -1.0);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0, 2, 5, 1); //blue couch
	SetShaderTexture("couchblue");
	SetShaderMaterial("couch");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	//right arm
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 1.0f, 1.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.75f, 1.0f, -1.0);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0, 2, 5, 1); //blue couch
	SetShaderTexture("couchblue");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	//******COFFEE TABLE******
	// table top
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 0.1f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(5.0f, 1.0f, -2.0);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1, 2, 0, 1); //yellow table
	SetShaderTexture("table");
	SetShaderMaterial("table");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	//table leg
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.2f, 1.0f, 0.2f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(5.0f, 0.0f, -2.0);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1, 2, 0, 1); //yellow table
	SetShaderTexture("table");
	SetShaderMaterial("table");
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	//decoration on table
	scaleXYZ = glm::vec3(0.3f, 0.3f, 0.3f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(5.0f, 1.25f, -2.0);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(0.7, 0.9, 1.0, 0.8); //blue globe
	SetShaderTexture("globe");
	SetShaderMaterial("globe");
	m_basicMeshes->DrawSphereMesh();
}
	/****************************************************************/

